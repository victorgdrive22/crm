// src/constants/translations.js

// Brazilian Portuguese translations for SalesForce Pro
export const translations = {
  // Common/General
  common: {
    loading: 'Carregando...',
    save: 'Salvar',
    cancel: 'Cancelar',
    delete: 'Excluir',
    edit: 'Editar',
    add: 'Adicionar',
    search: 'Buscar',
    filter: 'Filtrar',
    export: 'Exportar',
    import: 'Importar',
    close: 'Fechar',
    yes: 'Sim',
    no: 'Não',
    confirm: 'Confirmar',
    back: 'Voltar',
    next: 'Próximo',
    previous: 'Anterior',
    all: 'Todos',
    active: 'Ativo',
    inactive: 'Inativo',
    success: 'Sucesso',
    error: 'Erro',
    warning: 'Aviso',
    info: 'Informação'
  },

  // Application branding
  branding: {
    appName: 'SalesForce Pro',
    copyright: 'Todos os direitos reservados.'
  },

  // Authentication/Login
  auth: {
    signIn: 'Entrar',
    signInToAccount: 'Entre na sua conta',
    email: 'Email',
    emailAddress: 'Endereço de Email',
    password: 'Senha',
    enterEmail: 'Digite seu email',
    enterPassword: 'Digite sua senha',
    rememberMe: 'Lembrar de mim',
    forgotPassword: 'Esqueceu a senha?',
    signingIn: 'Entrando...',
    logout: 'Sair',
    invalidCredentials: 'Email ou senha inválidos',
    tooManyAttempts: 'Muitas tentativas falharam. Tente novamente mais tarde.',
    attemptsRemaining: 'tentativas restantes.',
    emailRequired: 'Email é obrigatório',
    validEmailRequired: 'Por favor, digite um endereço de email válido',
    passwordRequired: 'Senha é obrigatória',
    passwordMinLength: 'A senha deve ter pelo menos 6 caracteres',
    authenticating: 'Autenticando...',
    demoCredentials: 'Credenciais de Demonstração',
    salesRep: 'Representante de Vendas',
    manager: 'Gerente',
    director: 'Diretor',
    admin: 'Administrador',
    passwordResetInfo: 'A funcionalidade de redefinição de senha seria implementada aqui. Para demonstração, use as credenciais fornecidas.'
  },

  // Navigation
  navigation: {
    dashboard: 'Painel',
    deals: 'Negócios',
    contacts: 'Contatos',
    analytics: 'Análises',
    activity: 'Atividade',
    settings: 'Configurações',
    profile: 'Perfil',
    dashboardTooltip: 'Visão geral do pipeline e métricas',
    dealsTooltip: 'Gerenciar ciclo de vida de negócios e oportunidades',
    contactsTooltip: 'Gerenciamento de relacionamento com clientes',
    analyticsTooltip: 'Insights de desempenho e análise',
    activityTooltip: 'Linha do tempo de interação e histórico'
  },

  // Breadcrumb
  breadcrumb: {
    home: 'Início',
    dashboard: 'Painel',
    dealManagement: 'Gestão de Negócios',
    contactManagement: 'Gestão de Contatos',
    pipelineAnalytics: 'Análises de Pipeline',
    activityTimeline: 'Linha do Tempo de Atividades',
    settingsAdministration: 'Configurações e Administração',
    login: 'Entrar'
  },

  // Sales Dashboard
  salesDashboard: {
    title: 'Painel de Vendas',
    lastUpdated: 'Última atualização:',
    autoRefresh: 'Atualização automática a cada 5 minutos',
    totalPipeline: 'Pipeline Total',
    weightedPipeline: 'Pipeline Ponderado',
    activeDeals: 'Negócios Ativos',
    quotaAchievement: 'Conquista de Meta',
    salesPipeline: 'Pipeline de Vendas',
    dragDealsToUpdate: 'Arraste negócios para atualizar estágios',
    monthlyRevenueForecast: 'Previsão de Receita Mensal',
    forecast: 'Previsão',
    actual: 'Real',
    
    // Date range filters
    thisWeek: 'Esta Semana',
    thisMonth: 'Este Mês',
    thisQuarter: 'Este Trimestre',
    thisYear: 'Este Ano',
    
    // Probability filters
    allProbabilities: 'Todas as Probabilidades',
    highProbability: 'Alta (>70%)',
    mediumProbability: 'Média (30-70%)',
    lowProbability: 'Baixa (<30%)',
    
    // Territory filters
    allTerritories: 'Todos os Territórios',
    northAmerica: 'América do Norte',
    europe: 'Europa',
    asiaPacific: 'Ásia-Pacífico',
    
    // Pipeline stages
    lead: 'Lead',
    qualified: 'Qualificado',
    proposal: 'Proposta',
    negotiation: 'Negociação',
    closedWon: 'Fechado - Ganho',
    
    // Time indicators
    hoursAgo: 'horas atrás',
    daysAgo: 'dias atrás',
    justClosed: 'Recém fechado',
    minutesAgo: 'minutos atrás'
  },

  // Contact Management
  contactManagement: {
    title: 'Gestão de Contatos',
    subtitle: 'Gerencie seus relacionamentos com clientes e histórico de comunicação',
    addContact: 'Adicionar Contato',
    importContacts: 'Importar',
    noContactSelected: 'Nenhum Contato Selecionado',
    noContactSelectedDesc: 'Selecione um contato da lista ou adicione um novo para começar.',
    addNewContact: 'Adicionar Novo Contato',
    searchPlaceholder: 'Pesquisar contatos por nome, email ou empresa...',
    allContacts: 'Todos os Contatos',
    activeContacts: 'Contatos Ativos',
    inactiveContacts: 'Contatos Inativos',
    selected: 'selecionados',
    contacts: 'contatos',
    exportSelected: 'Exportar Selecionados',
    deleteSelected: 'Excluir Selecionados',
    mergeContacts: 'Mesclar Contatos',
    
    // Contact fields
    firstName: 'Nome',
    lastName: 'Sobrenome',
    fullName: 'Nome Completo',
    email: 'Email',
    phone: 'Telefone',
    company: 'Empresa',
    position: 'Cargo',
    status: 'Status',
    tags: 'Tags',
    notes: 'Notas',
    lastContactDate: 'Última Data de Contato',
    
    // Contact form
    contactForm: {
      addContact: 'Adicionar Contato',
      editContact: 'Editar Contato',
      personalInfo: 'Informações Pessoais',
      companyInfo: 'Informações da Empresa',
      additionalInfo: 'Informações Adicionais',
      enterFirstName: 'Digite o nome',
      enterLastName: 'Digite o sobrenome',
      enterEmail: 'Digite o email',
      enterPhone: 'Digite o telefone',
      enterCompany: 'Digite a empresa',
      enterPosition: 'Digite o cargo',
      enterNotes: 'Digite as notas...',
      selectTags: 'Selecione tags',
      firstNameRequired: 'Nome é obrigatório',
      lastNameRequired: 'Sobrenome é obrigatório',
      emailRequired: 'Email é obrigatório',
      validEmailRequired: 'Por favor, digite um email válido',
      phoneRequired: 'Telefone é obrigatório',
      companyRequired: 'Empresa é obrigatória'
    }
  },

  // Quick Actions
  quickActions: {
    title: 'Ações Rápidas',
    quickNavigation: 'Navegação Rápida',
    addNewDeal: 'Adicionar Novo Negócio',
    addNewDealDesc: 'Criar uma nova oportunidade de venda',
    addContact: 'Adicionar Contato',
    addContactDesc: 'Adicionar um novo contato de cliente',
    scheduleMeeting: 'Agendar Reunião',
    scheduleMeetingDesc: 'Agendar uma chamada ou demonstração',
    sendEmail: 'Enviar Email',
    sendEmailDesc: 'Redigir e enviar email',
    
    // Modal forms
    dealTitle: 'Título do Negócio',
    enterDealTitle: 'Digite o título do negócio',
    companyName: 'Nome da Empresa',
    dealValue: 'Valor do Negócio',
    createDeal: 'Criar Negócio'
  },

  // Performance Metrics
  performanceMetrics: {
    title: 'Métricas de Desempenho',
    quota: 'Meta',
    achieved: 'Alcançado',
    dealsWon: 'Negócios Ganhos',
    dealsLost: 'Negócios Perdidos',
    avgDealSize: 'Tamanho Médio do Negócio',
    conversionRate: 'Taxa de Conversão',
    quotaProgress: 'Progresso da Meta'
  },

  // Activity/Tasks
  activity: {
    upcomingTasks: 'Tarefas Próximas',
    recentActivity: 'Atividade Recente',
    viewAll: 'Ver Todas',
    dueToday: 'Vence Hoje',
    overdue: 'Atrasado',
    completed: 'Concluído',
    
    // Activity types
    email: 'Email',
    call: 'Chamada',
    meeting: 'Reunião',
    task: 'Tarefa',
    note: 'Nota',
    
    // Time indicators
    today: 'Hoje',
    yesterday: 'Ontem',
    thisWeek: 'Esta Semana',
    lastWeek: 'Semana Passada',
    thisMonth: 'Este Mês',
    lastMonth: 'Mês Passado'
  },

  // Deal stages and statuses
  dealStages: {
    lead: 'Lead',
    qualified: 'Qualificado',
    proposal: 'Proposta',
    negotiation: 'Negociação',
    closedWon: 'Fechado - Ganho',
    closedLost: 'Fechado - Perdido',
    discovery: 'Descoberta',
    onHold: 'Em Espera'
  },

  // Notifications
  notifications: {
    newNotifications: 'Novas Notificações',
    markAllRead: 'Marcar Todas como Lidas',
    noNotifications: 'Nenhuma notificação',
    dealUpdated: 'Negócio atualizado',
    contactAdded: 'Contato adicionado',
    meetingReminder: 'Lembrete de reunião',
    taskDue: 'Tarefa vencendo'
  },

  // Months for charts and dates
  months: {
    jan: 'Jan',
    feb: 'Fev',
    mar: 'Mar',
    apr: 'Abr',
    may: 'Mai',
    jun: 'Jun',
    jul: 'Jul',
    aug: 'Ago',
    sep: 'Set',
    oct: 'Out',
    nov: 'Nov',
    dec: 'Dez'
  },

  // User roles
  userRoles: {
    salesRep: 'Representante de Vendas',
    salesManager: 'Gerente de Vendas',
    salesDirector: 'Diretor de Vendas',
    systemAdmin: 'Administrador do Sistema'
  },

  // Form validation
  validation: {
    required: 'Este campo é obrigatório',
    invalidEmail: 'Por favor, digite um email válido',
    minLength: 'Deve ter pelo menos {min} caracteres',
    maxLength: 'Deve ter no máximo {max} caracteres',
    invalidPhone: 'Por favor, digite um número de telefone válido',
    invalidUrl: 'Por favor, digite uma URL válida'
  },

  // Currency and formatting
  formatting: {
    currency: 'R$',
    thousand: 'mil',
    million: 'milhão',
    billion: 'bilhão'
  },

  // Tags/Categories
  tags: {
    enterprise: 'Empresa',
    tech: 'Tecnologia',
    decisionMaker: 'Tomador de Decisão',
    manufacturing: 'Manufatura',
    midMarket: 'Mercado Médio',
    procurement: 'Compras',
    marketing: 'Marketing',
    fastGrowth: 'Crescimento Rápido',
    smallBusiness: 'Pequena Empresa',
    healthcare: 'Saúde',
    operations: 'Operações',
    finance: 'Finanças',
    innovation: 'Inovação',
    security: 'Segurança'
  }
};

export default translations;